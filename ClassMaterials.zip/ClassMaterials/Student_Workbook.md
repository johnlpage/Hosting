# MongoDB Enterprise Microservice Exercises

**Author:** John Page  
**Date:** April 2, 2025
---

<div style="border: 2px solid black; background-color: springgreen; padding: 10px;">
  This workbook is intended to be used as part of a two-day instructor led workshop, you should not begin until your 
instructor tells you to as there are concepts to learn in advance of starting building.
</div>


## Sprint Zero - Setup

### Prerequisites

The following should be installed and tested before beginning this workshop:

* _git_ with access to _GitHub_ (Not Mandatory)
* [_curl_](https://curl.se/download.html) and [_jq_](https://jqlang.org/download/)**
* Java 17 or higher with an IDE you know how to use.
* Apache Maven (mvn)
* MongoDB Compass, or MongoDB Shell or Atlas Data Explorer

** jq is a useful JSON formatter and filtering tool for the command line.

### Access to MongoDB Atlas

You will need access to and credentials for a MongoDB Atlas Environment. This can be cloud hosted Atlas or the 
Atlas local development environment. You should test this by connecting with MongoDB Compass or the MongoDB Shell 
where possible.

Specific instructions will vary by environment.

### WINDOWS ONLY: Setup bash command line tooling

We do this so Windows, Linux and Mac all work the same way, if you have WSL installed you could probably just type bash.

#### git and bash
```
winget install --id Git.Git -e --source winget  
```
1. Configure IntelliJ to Use Git Bash:

* Open IntelliJ IDEA.
* Go to File > Settings (or Ctrl+Alt+S).
* Navigate to: **Tools > Terminal.**
* In the __Shell Path__ field, replace the current shell (PowerShell or cmd.exe) path with the Git Bash path:
_"C:\Program Files\Git\bin\bash.exe"_
* Click OK to save the settings.
3. Restart the Terminal:
* Open the integrated terminal in IntelliJ (Shift+Alt+F12 or __View > Tool Windows > Terminal)__.
* You should now be in a Git Bash shell.


### Obtain Memex example code

Use Git to fetch the code from GitHub, if you do not have access to GitHub then you can 
request a zipfile from your instructor.

Change to the directory where you want to work and either clone the repository or unzip a supplied zip file. We are 
disconnecting from the upstream repo as we aren't going to be sending back pull requests.

```shell
git clone --depth 1 https://github.com/johnlpage/MongoEnterpriseMicroserviceExamples.git
cd MongoEnterpriseMicroserviceExamples
rm -rf .git
git init .
git add *
git commit -m "Copied Memex Base"

echo "Done"

```

### Generate sample data

The repository comes with some  sample data. This data represents the vehicle inspection (MOT Test) data for the UK 
for  2021/2022, the raw data in CSV form can be downloaded from data.gov.uk but this is a very large data set and is also in relational table format requiring it all to be joined into a 40GB JSON file. The source JSON data once transformed looks like this.


```json
{
    "testid": 10, 
    "testmileage": 81625, 
    "testdate": "2022-04-06", 
    "fueltype": "PETROL", 
    "capacity": 1596, 
    "testtype": "Normal Test", 
    "vehicle": {"colour": "RED", "make": "FORD", "model": "FIESTA", "vehicleid": 3068290}, 
    "firstusedate": "2017-04-01", 
    "postcode": "BL", 
    "testclass": 4, 
    "testresult": "Passed", 
    "faileditems": [
        {
            "rfrtype": "A", 
            "rfrid": 31195, 
            "details": {
                "item": { "itemname": "Tread depth", "category": {"itemname": "Tyres"} }, 
                "minoritem": "N", 
                "description": "Dangerous", 
                "rfrid": 31195, 
                "text": "Tyre tread depth not in accordance with the requirements"
            }, 
            "location": {"longitudinal": "Rear", "lateral": "Left", "vertical": ""}
        }, 
        {
            "rfrtype": "A", 
            "rfrid": 31194, 
            "details": {
                "item": { "itemname": "Tread depth", "category": {"itemname": "Tyres"} }, 
                "minoritem": "N", 
                "description": "Dangerous", 
                "rfrid": 31194, 
                "text": "Tyre tread depth not in accordance with the requirements"
            }, 
            "location": {"longitudinal": "Rear","lateral": "Right", "vertical": ""}
        }
    ]
}

```

To avoid the need to download all this data for larger scale testing, the original JSON has been turned into a 
statistical model allowing us to generate data of the same form. To do so we need to compile the data generator and 
run it on the model. To save time during this workshop we will work with only a sample of 1 million documents 
although we can generate as many as we require. 

Here are command line instructions or use your IDE to import and build the data generator and run it.

```shell
cd DataGen
mvn clean package
java -jar target/Datagen-1.0.jar Inspections 100000 mot.json


```

We now have sample data and have shown we have a working Java environment.

## Build MEMEx Services

MEMEx (Mongo Enterprise Microservice Examples )  is a set of example microservice services with HTTP 
endpoints  built using Spring Boot and Java which provide common capabilities built using best practices for 
MongoDB.
The code uses a REST Controller and exposes as web services however the Service and Repository classes behind 
them  could be used with File, Batch or Queue controllers like Kafka. A simple Kafka example is included too to show 
how this can work.

The MEMEx examples use the UK vehicle inspection data as sample data and provide examples of bulk loading and updating, querying and searching data, transactional data updates and bulk extract and reporting as well as various features such as dynamic query costing that would be advisable in a user facing scenario. There is also a simple User interface included to show how the interactive endpoints might be used.

In these workshops we will take the MEMEx code and extend it to/ replace it with our own dataset and queries to meet 
business requirements we are given. The first step is to ensure the base code compiles and runs as supplied.

### Run Service

Open up the project in your IDE  (IntelliJ)  at top level of MongoEnterpriseMicroserviceExamples


___In IntelliJ, pay attention to the pop-ups for things like "Enable Annotation Processing", "Maven Build Scripts 
Found" 
and "Enable google-java-format" and accept these if you have them.___

Edit `memex/src/main/resources/application.properties` to add your database connection string in `spring.data.mongodb.uri`, it will normally start  with `mongodb+srv://` when using [Atlas](https://cloud.mongodb.com/login).

Either run the application (memex) in your IDE.

To run it from the command line open a terminal and use this.

```shell
cd memex
mvn spring-boot:run 

```

To run in the IDE open  memex/src/main/java/com.johnlpage.memex/memexApplication,java then on the toolbar select 
"Current file" in the dropdown and click  &#9654;. 

___Enable Annotation processing if requested in a popup.___


You will then see  the service start

```txt
2025-02-13T11:17:12.108Z com.johnlpage.memex.memexApplication       : Started memexApplication in 1.397 seconds 
(process running for 1.56)
2025-02-13T11:17:12.149Z  INFO 28183 --- [memex] [           main] c.j.m.s.MongoDbPreflightCheckService     : PREFLIGHT CHECK
2025-02-13T11:17:12.149Z  WARN 28183 --- [memex] [           main] c.j.m.s.MongoDbPreflightCheckService     : THIS IS CONFIGURED TO AUTOMATICALLY CREATE INDEXES - THIS IS NOT RECOMMENDED IN PRODUCTION
2025-02-13T11:17:12.236Z  INFO 28183 --- [memex] [           main] c.j.m.s.MongoDbPreflightCheckService     : PREFLIGHT CHECK COMPLETE
2025-02-25T10:06:26.436Z  INFO 17344 --- [memex] [)-192.168.7.236] o.a.c.c.C.[Tomcat].[localhost].[/]       : Initializing Spring DispatcherServlet 'dispatcherServlet'
2025-02-25T10:06:26.436Z  INFO 17344 --- [memex] [)-192.168.7.236] o.s.web.servlet.DispatcherServlet        : Initializing Servlet 'dispatcherServlet'
2025-02-25T10:06:26.438Z  INFO 17344 --- [memex] [)-192.168.7.236] o.s.web.servlet.DispatcherServlet        : Completed initialization in 0 ms
```

_If you see a message about a MongoSocketOpenException this means it was unable to connect to the database and you
need to double check your connection string_

_The last few lines may not show after PREFLIGHT on Windows_


We can now use curl to POST to the `/api/inspections` endpoint sending adding our sample JSON date. From a Terminal 
window (in IDE or otherwise).  Run the following command and 
verify the output. It's telling us we added one million new records. If this takes a long time you may have a 
smaller Atlas instance and perhaps generating only 100,000 sample documents would be better.

```shell
cd DataGen
curl  -X POST "http://localhost:8080/api/inspections" -H "Content-Type: application/json" -T mot.json
```

The output is 
```
{"updates":0,"deletes":0,"inserts":1000000,"success":true,"message":""}
```

Note that if you run this command again - you will get a response saying that nothing was changed, this is because 
the default mode is to not perform any operation if the data already exists and has not changed in any way.

Against a Cloud M10 cluster with a reasonable upload speed from out client we can expect this to load in about 35 seconds, about 2,800 per second -
 this is fairly slow by MongoDB standards but an M10 is also a small cluster and the network distance from desktop to cloud has an impact too.
 

We can retrieve one of the inspection records to show it has been stored in the databases using GET operation 
against the `/api/inspections/id` endpoint.

```shell
curl -s http://localhost:8080/api/inspections/id/124 | jq
```

The `-s` options makes curl only output the data returned and piping it to `jq` formats it nicely, without that we 
are returning JSON in a compact form all on one line and with no highlighting.

We also hve an example of retrieving by another field, in the case of the inspection data we have an example 
endpoint to retrieve it by vehicle model `/api/inspections/model/<Vehicle Model>`. 

```json
curl -s http://localhost:8080/api/inspections/model/ASTRA | jq 
```

The JSON we loaded and the JSON we retrieve are the same, as we would expect. If we take a  look inside the 
database at how it's been stored we can see an extra field, payload. The payload field is being used to store any 
fields that we are sending that we have not provided an explicit  mapping to a class member  for.  We could make this 
an error and insist that the JSON has only values we are aware of but we would like to be able to store any additional 
data that comes in the future. This is taking advantage of the flexible schema options in MongoDB.

Looking with compass, the MongoDB shell (mongosh) or even in the Atlas data explorer we see the document looks like 
this, with failedItems and fueltype being unmapped fields in our model. _You may note this is not actually valid JSON 
but rather Javascript showing where data types like `Long` and `ISODate` do not exist in JSON. MongoDB can display then 
like this or using extensions to JSON which _are_ valid JSON but are less readable showing a Long as `{ 
"$numberLong": "<1001>" }` for example. It is important to be aware that standard JSON does not support numeric 
types apart from Double and does not have date or other data type support.


```json
{
  _id: Long('1001'),
  testclass: '4',
  testtype: 'Re-Test',
  testresult: 'Passed',
  testmileage: Long('26239'),
  postcode: 'SO',
  vehicle: {
    vehicleid: Long('8597788'),
    make: 'VAUXHALL',
    model: 'ASTRA',
    colour: 'SILVER'
  },
  capacity: Long('1968'),
  firstusedate: ISODate('2022-07-20T00:00:00.000Z'),
  payload: { faileditems: [], fueltype: 'PETROL' }
}
```

<div style="border: 2px solid black; background-color: springgreen; padding: 10px;">
  At this point your instructor will talk to you about data ingestion, streams, durability and batching. Do not 
continue past this point until told to by your instructor.
</div>

## Sprint One

```
 From: ProductManager@SomeCo.com 
 To: DataTeam@SomeCo.com
 Subject:  New data source to be introduced
 
 Our marketing department has requested we provide them with access to the UK Registered
 Company and PSC data. PSC  stands for "Persons of Significant Control" and is published 
 by the UK government showing people who control all registered businesses. It's not to
 ask why they want this, it  will be a typically vague Marketing answer. Anyway we have
 that data. It's 13 Million records and a relatively small 10GB and it gets re-released 
 monthly, they want us to store it and provide access as it's too much for Excel directly. 
 
 We aren't worrying about the download part right now just providing a storage and 
 access service although no doubt they will ask for more as Excel will struggle. It's not
 a rigid schema as some fields seem to be optional and it's published as JSON, we
 cannot discount the format changing  in future though and we we need to ensure we are 
 recording changes
|
```

To save time we will work with just a sample in development, we don't want to be loading all 10GB every time.

The raw data is available from  [www.gov.uk](http://www.gov.uk/guidance/companies-house-data-products) but you can 
get a copy to work with here __[Download Company data](http://todo.here)__


### Sprint One Backlog ( 1 Hour allocated )

* Examine JSON and identify fields we think it might be important to explicitly model.
* Create Model, Repository, Service and Controller Classes for the Company data based on the example classes.
* Load in our Company data
* Test retrieving companies by their companyNumber

### Step by step

Make the following changed in your IDE, run and test the code as frequently as possible. 

#### Model
Under the _model_ subdirectory, duplicate the class `VehicleInspection` using copy and paste and rename
the new class  to `Company`. Remove all fields except `testid`, `version`, `deleted` and `payload`.

Note how we define payload using `@JsonAnySetter` and `@JsonAnyGetter` - these will determine the type of any field 
we have not explicitly added and then add them to a HashMap, this brings the _Dynamic Scheme_  model of MongoDB to 
Spring and lets us gracefully handle fields we haven't explicitly mapped.


We have the option of keeping the class member name the same as the JSON, and also mapping to a different field name 
in the DB. Today we will keep the Json, Java and Database having the same field names for simplicity although some 
prefer camelCase in java but not in the databases or JSON.

Change the identifier field from 

```java
@Id Long testid;
```

to 

```java
@Id String companyNumber;
``` 

This is our primary key field,  we need to indicate what field in the JSON contains it and also the type. MongoDB will 
store  this value in a field called _id as it already uses that field as a unique, indexed primary keyand we do not 
therefore need an additional index.

We also want to use a different collection so change:

```java
@Document(collection="vehicleinspection")
```


to
```java
@Document(collection="company")
```

#### Repository

Now duplicate the class `repository\VehicleInspectionRepository` this defines the database code and queries that 
interact with the model. Call the new class `CompanyRepository`.
Using Find and Replace __(not Refactor!)__, in this class alone replace the string *VehicleInspection* with 
*Company* in all names of classes, members and functions. Then to the same to replace *Long* with *String* , this is 
for the data type of the primary key.

#### Services

For each of the services names with `VehicleInspection<Something>Service` in `services/` repeat the above action. 
Duplicate the class renaming it to `Company<Something>Service` again do not use Refactor->Rename for this, just find 
and replace or manually change. Otherwise, it renames things in other classes too.

When changing `CompanyHistoryService` you need to change the type of `id` from _Long_ to _String_.

When changing `CompanyPreWriteTriggerService` delete the contents of the function `modifyMutableDataPreWrite` and 
leave it with an empty body.

In `CompanyQueryService` change the type of _id_ from a Long to String in `getById`

##### Controller

Duplicate `controller/VehicleInspectionController` and create `CompanyController`, using find and replace to change 
*VehicleInspection* to *Company* everywhere in it.

Use find and replace change "/inspections" to "/companies" so we have new endpoints.

Remove the function `oneinspection` and the @GetMapping above it
Remove the function `vehicleById` and the @GetMapping above it
Remove the function `getInspectionsByModel` and the `@GetMapping above it

These are examples of things we will either covler later int he course by re-adding or you can look at later in the vehicleinspection.

In `getById` and `dataAtDate` change  parameter type of id to a `String`


### Test

Now we should be able to load in our Company data and Query by ID. We have moved our services to work with a new 
data set.

#### Load in test data

```shell
curl  -X POST "http://localhost:8080/api/companies" -H "Content-Type: application/json" -T companies250k.json
```

#### Retrieve data

```shell
curl "http://localhost:8080/api/companies/id/11878997" | jq
```

<div style="border: 2px solid black; background-color: springgreen; padding: 10px;">
  At this point your instructor will talk to you about queries, query planners and indexing. Do not 
continue past this point until told to by your instructor.
</div>

## Sprint Two

```
 From: ProductManager@SomeCo.com 
 To: DataTeam@SomeCo.com
 Subject:  Initial query requirements
 
I've Spoken to Marketing - apparently they need to fetch data and pull it into their 
"Marketing Apps"  (Probably Excel or ChatGPT 😂 ). I've agreed we will give them web
service and a test UI. They need to be able to query businesses by  "Town", by 
"Nationality" of  associated person and by "Incorporation Date"  ranges. Not a huge 
team BTW - few  queries per second probably but they want reasonable response times.

```

__When running MEMEx we already have a test UI at http://localhost:8080 and the code for that is in the repo. It has a 
mock-up for some configuration endpoints but what's important are the endpoints it calls.__

### Sprint Two Backlog

* Update Data Model
  * Move Incorporation date to a top level field and add an endpoint to get by range using standard repository methods.
  * Map the Address field to its own object
  * Update the Model to make `Persons` an array (Can be array of of HashMaps)

* Implement a Query By Example for the Address field 
* Add a MongoDB query/endpoint to get persons of a given nationality 
* Update test UI config/code to view our new company data.
* Implement any required queries in the UI so they can query by code (Excel) or with the UI

### Step By Step


#### Create a model for Address

Copy and paste the model for `Company` renaming to `Address` , remove the `@Document` annotation and add the 
following to the class, keep payload parts as they are. Do don't need a deleted field in addresses as they are part 
of the larger company record in the input.

```java


@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Address {


 String addressLine1;
 String addressLine2;
 String postTown;
 String postCode;
 String region;
 String country;
 String careOf;

 /**
  * Use this to capture any fields not captured explicitly As MongoDB's flexibility makes this easy
  * we almost want to do it by default. We could even put it into a base model we derive from.
  */
    


```

#### Update the model for Company

Modify `Company` to add the following three fields to the model, you will need to import _java.util.List_.

```java
Date incorporationDate;
Address regAddress;
List<Map<String,Object>> people;
```

We could explicitly map a Person to a dedicated Class too, but we don't need to, this shows another way we can map data 
easily and array of Maps. 

#### Update the data

Restart the services then reload the data, as the format has changed (and we are using the default "Replace" mode) it 
will  update it  all to match the new format.

```shell
curl -s -X POST "http://localhost:8080/api/companies?E" -H "Content-Type: application/json" -T companies250k.json
```
Our new schema looks like this:

```json
{
    "_id": "11743365", 
    "incorporationDate": {"$date": "2018-12-28T00:00:00.000Z"}, 
    "regAddress": {
        "addressLine1": "372 OLD STREET", 
        "addressLine2": "335 ROSDEN HOUSE", 
        "postTown": "LONDON", 
        "postCode": "EC1V 9LT", 
        "region": "", 
        "country": "UNITED KINGDOM", 
        "payload": {"POBox": "", "careOf": ""}
    }, 
    "people": [
        {
            "address": {
                "addressLine1": "335 Rosden House", 
                "country": "United Kingdom", 
                "postTown": "London", 
                "postCode": "EC1V 9LT", 
                "addressLine2": "372 Old Street"
            }, 
            "countryOfResidence": "United Kingdom", 
            "dateOfBirth": {"month": 1, "year": 1968}, 
            "etag": "a7fd90d56c0f8d39b7db8d0622aba5064d189f54", 
            "kind": "individual-person-with-significant-control", 
            "links": {"self": "/company/11743365/persons-with-significant-control/individual/_UB_a_HCeLneC_nbdqvjtwnr7mI"}, 
            "name": "Mr Phillip Jerome Mascarenhas", 
            "nameElements": {"forename": "Phillip", "middleName": "Jerome", "surname": "Mascarenhas", "title": "Mr"}, 
            "nationality": "American", 
            "naturesOfControl": ["ownership-of-shares-75-to-100-percent", "voting-rights-75-to-100-percent", "right-to-appoint-and-remove-directors"], 
            "notifiedOn": "2018-12-28"
        }
    ], 
    "payload": {
        "mortgages": {"numMortSatisfied": 0, "numMortOutstanding": 0, "numMortPartSatisfied": 0, "numMortCharges": 0}, 
        "dissolutionDate": "", 
        "companyName": "!BIG IMPACT GRAPHICS LIMITED", 
        "companyStatus": "Active", 
        "companyCategory": "Private Limited Company", 
        "limitedPartnerships": {"numLimPartners": 0, "numGenPartners": 0}, 
        "confStmtNextDueDate": {"$date": "2025-12-29T00:00:00.000Z"}, 
        "uRI": "http://business.data.gov.uk/id/company/11743365", 
        "confStmtLastMadeUpDate": {"$date": "2024-12-15T00:00:00.000Z"}, 
        "previousNames": [], 
        "returns": { "nextDueDate": {"$date": "2020-01-25T00:00:00.000Z"}, "lastMadeUpDate": "" }, 
        "countryOfOrigin": "United Kingdom", 
        "accounts": {
            "accountCategory": "DORMANT", 
            "nextDueDate": {"$date": "2025-09-30T00:00:00.000Z"}, 
            "accountRefMonth": 12, 
            "accountRefDay": 31, 
            "lastMadeUpDate": {"$date": "2023-12-24T00:00:00.000Z"}
        }, 
        "SICCode": [
            "18129 - Printing n.e.c.", "59112 - Video production activities", "63120 - Web portals", 
            "74201 - Portrait photographic activities"
        ]
    }
}
```
Now we need to add some endpoints and explore the test GUI.

#### Query by Example for town in address.

Query By Example is a hybrid concept in Spring Data, it's similar to  a native MongODB query in the sense you query
by giving an  object of the type you are looking for. We can add this to our Service then Controller.

Rename `getInspectionByExample` in  `CompanyQueryService` if we haven't already to `getCompanyByExample` and change 
it to read this.

```java
public Slice<Company> getCompanyByExample(
       Company probe, int page, int size) {
 ExampleMatcher matcher = ExampleMatcher.matching().withIgnoreNullValues();
 Example<Company> example = Example.of(probe, matcher);
 return repository.findAll(example, PageRequest.of(page, size));
}
```



Copy `getInspectionsByModel` from `VehicleInspectionController` to `CompanyController` and fix up the types to query 
by `Address.PostTown` to add the endpoint `/companies/posttown/{town}`. The IDE Autofixer will do 90% of this for you. 
The code will look like this when you have done.

```java
/**
* JPA Get By Example Query - Needs an Index to be efficient It still finds ALL the results each
* time and returns a subset
*/
@GetMapping("/companies/posttown/{town}")
public ResponseEntity<PageDto<Company>> getCompanyByPostTown(
       @PathVariable String town,
       @RequestParam(name = "page", required = false, defaultValue = "0") int page,
       @RequestParam(name = "size", required = false, defaultValue = "10") int size) {


 // This is where we are hard coding a query for this endpoint.
 // By creating an example of the class, clumsy but works.
 Company example = new Company();
 Address a = new Address();
 a.setPostTown(town);
 example.setRegAddress(a);


 // Use the line below for immutable model
 // VehicleInspection probe = VehicleInspection.builder().model(model).build();
 Slice<Company> returnPage = queryService.getCompanyByExample(example, page, size);
 PageDto<Company> entity = new PageDto<>(returnPage);
 return ResponseEntity.ok(entity);
}

```

Now restart the service and test.

```shell
curl "http://localhost:8080/api/companies/posttown/GLASGOW"
```

#### Add an index for our new query requirement


this will be slow as it has no index yet - time it using 

```shell
time curl "http://localhost:8080/api/companies/posttown/GLASGOW"
```
We should create an index on "regAddress.postTown". Even if we don't plan to create it manually we should verify it's 
there  otherwise this endpoint will be expensive. We can modify the preflight checks in 
`service/MongoDbPreFlightCheckService` - update this to add in Company and the required index in the schema

```java
private static final String SCHEMA_AND_INDEXES =
"""
{
   "collections" : [
     { "name" : "vehicleinspection" ,
       "indexes": [ { "vehicle.model" : 1 }],
       "searchIndexes" : [ { "name": "default", "definition" : { "mappings" : { "dynamic" : true, fields: {}} }}]
     },
     { "name" : "vehicleinspection_history" ,
       "indexes" : [ { "recordId" : 1, "timestamp" : 1 }]
     },
      { "name" : "company" ,
       "indexes": [ { "regAddress.postTown" : 1 }]
     }
   ]
}
""";
```

Restarting will take a little extra time to create this index, this is one reason we don't normally
set auto-creation of indexes. Spring has annotations for definition and optional auto creation of indexes but best  
practice is to use a preflight class and then figure out when and how you will create them. It's also better to 
think  about indexing holistically and in one place generally. You could of course make a preflight per collection  
or set of collections just by duplicating the class.

#### Add an endpoint using auto-generated query in the repository.

We can also query by an explicit field using JPA queries and the repository, best practices is not to call the 
repository directly from the controller but to have a service for any business logic. Let's add in an endpoint to 
get companies incorporated in a specific date range using a JPA query.

Add the following to `CompanyQueryService`.

```java
public List<Company> getCompanyByIncorporationDate(Date from, Date to) {
 return repository.findCompaniesByIncorporationDateBetween(from, to);
}
```

Your IDE may then  prompt you to  add this to `CompanyRepository`, if not add it manually. You don't need to define the 
body for this  just add it to the interface and MongoRepository will write the query for you behind the scenes.

```java
List<Company> findCompaniesByIncorporationDateBetween(Date from, Date to);
```


Finally we add an Endpoint to call this in CompanyController. 

```java
// Simple Repository Query Example
@GetMapping("/companies/incorporationDate")
public ResponseEntity<List<Company>> getCompaniesByIncorporationDate(
       @RequestParam(name = "from", required = false, defaultValue = "20000101")    @DateTimeFormat(pattern="yyyyMMdd") Date from,
       @RequestParam(name = "to", required = false, defaultValue = "20321231")   @DateTimeFormat(pattern="yyyyMMdd")  Date to) {


 return ResponseEntity.ok(queryService.getCompanyByIncorporationDate(from,to));
}
```

Restart and test this, we are using jq here to filter fields in the output to make it clearer.

```shell
curl -s "http://localhost:8080/api/companies/incorporationDate?from=20041005&to=20041008" | jq '.[]|{incorporationDate,
companyName}'

```

We still need an index for this query as none of our existing indexes are on incorporationDate, feel free to add one.

#### Add an explicit MongoDB query in the repository

What about querying the dynamic data?  We have a _People_ array, but it contains only _HashMap_ objects, so without 
explicitly calling out a person as a new data class how can we query by the nationality of a person? Here we can 
add a query to the repository explicitly - something which gives us a lot more control and the full MongoDB query 
api to work with.

If we look in `CompanyRepository` we can see a lot of commented out code, take the part about Custom Query by make and 
model and copy that out of the comments. rewrite it to query by _people.nationality_ a field in mongodb that our 
Java code  isn't explicitly aware of. We could extend this query to use any of MongoDB's query capabilities which go 
far beyond what JPA provides.

```java
@Query("{ 'people.nationality': ?0 }")
List<Company> findOwnerNationality(String nationality);
```

Add this to `CompanyQueryService`

```java
public List<Company> getCompaniesByPersonsNationality(String nationality) {
 return repository.findOwnerNationality(nationality);
}
```

And add it to `CompanyController`

```java
// Simple Repository Query Example
@GetMapping("/companies/ownerNationality/{nationality}")
public ResponseEntity<List<Company>> getByOwnerNationality(   @PathVariable String nationality) {
 return ResponseEntity.ok(queryService.getCompaniesByPersonsNationality(nationality));
}

```

Now we can test by querying for companies where one of the people in charge is an american.

```shell
curl "http://localhost:8080/api/companies/ownerNationality/American"
```

___Tip: in application.properties is a line you can use to see the queries being run for these operations, you can 
and should comment it out in production it reads:___

```txt
logging.level.org.springframework.data.mongodb.core=DEBUG
```

#### Flexible Query Endpoints

We have added endpoints explicitly in this exercise, but what if we want to offer a generic query endpoint where the 
caller can define their own query. the MEMEx code includes this in the query service. It also includes a query 
_costing_ mechanism so you can assess what queries you might block, or log because they need an index added, or even 
direct to additional or different replicas of the data.

Take a look at CompanyQueryService and mongoDBNativeQuery - this reads a query as a JSON String, costs it and runs 
it. You can see the code in `repository/optimized/OptimizedMongoQueryRepository` if you want.

The JSON you pass to define a query operation is

```json
{
   "filter": { "field1" : "value", "field2" : "value" },
   "sort": { "field1": "1 or -1", "field2": "1 or -1" },
   "projection": { "field1": true, "fieldN": true },
   "skip": "<Number: default 0>",
   "limit": "<Number: default 1000>"
}


```

To see this in action point your BROWSER at localhost:8080 where there is an example of a web UI pointing at the API 
you are writing. The code for this is in `main/resources/public` and is a very simple example not intended for 
you to build upon for production but to assist in testing. It has one HTML file, one Stylesheet and one Javascript 
file as well as a directory _dummyapi_ with a couple of JSON documents that configure it, these JSON documents would 
likely, in a real app be returned from an API.

Use this to fetch some vehicle inspection data so you understand what it does.

Look at `resources/public/main.js` and the function runGridQuery() which fetches data to populate the search grid. and 
you can  see how we run the query shown in the UI. We are providing a far more flexible service to our endpoint 
users (More GraphQL like in some ways) but unlike typical GraphQL keeping track of compute/query costs.

In the `main.js` file to change "inspections" to "companies" so we are using your company data. It appears in 3 places.

This UI fetches json files from  `/dummyapi` to get metadata, modify gridFields and queryableFields to get this working 
for your Company  data.  Provide the option to query the the fields Marketing asked `incorporationDate, person.
nationality , registeredAddress.postTown` for and one  more of your choice from `payload`. As a tip  you can use > 
amd < in numeric and date query fields too

__gridFields.json__
```json

{
  "Company Number": "companyNumber",
  "Name": "payload.companyName",
  "Nationality Queried": "people.nationality",
  "Person Matched": "people.name",
  "Incorp. Date": "incorporationDate",
  "Town": "regAddress.postTown"
}
```

__queryableFields.json__

```json
{
  "companyNumber": "",
  "Town=regAddress.postTown":"",
  "Nationality=people.nationality": [
    "British",
    "American"
  ],
  "Surname=people.nameElements.surname": "",
  "Date Incorporated=incorporationDate": ""
}

```
We can make a field an Array of options, a number or a string by setting the value to "" or 0. Our date field is 
interesting. How can we tell MongDB this is a date not a just string, This is where generic queries sent as JSON become 
tricky. MongoDB uses a concept called Extended JSON (JSON) to pass data types over JSON and in our nativeQuery 
function we are using the MongODB EJSON parser. This means if we sent a dates as `{"$date": "<ISO-8601 Date/Time 
Format>"}` it knows to convert to a Java Date. The frontend detects if something is a date and if so sends it 
wrapped in this syntax. 

Test with a date in the incorporated field. __You may need to clear your browser cache to get it to pick up the new 
JSON files, or open the developer console in chrome and disable caching__. Also, this being a Java app you will need 
to restart the server to pick up any changes to these source files as they are compile into the JAR.

<div style="border: 2px solid black; background-color: springgreen; padding: 10px;">
  At this point your instructor will talk to you about the difference between MongoDB and the Atlas Developer data 
platform and about Atlas search and Lucene database BTree indexes. Do not continue beyond this point until asked to  
do so.
</div>


## Sprint Three - Atlas Search and the Developer Data Platform


```
 From: ProductManager@SomeCo.com 
 To: DataTeam@SomeCo.com
 Subject:  Search Requirements

The Marketing team have added about a dozen more fields they want to query on, 
notably people's names. they have also asked about  just having a 'Google' box 
and about fuzzy matching.

What can we do for them?
|
```

### Sprint Three - Backlog

* Investigate the full text search feature in the test UI.
* Add a full text index for Companies on all fields
* * Add a 'Fuzzy' option for peoples names as a Java HTTP Endpoint
* Add a multi field keyword index
* Are we able to see what are the 'Best' matches?

### Step By Step

#### Create an Atlas search index.

Look at the test UI, there is a full text box and as you type into it you can see the most basic set of parameters to 
send to an Atlas Search query. The code to run this is in `OptimizedMongoQueryRepository::atlasSearchQuery` , we can 
modify the query from the service though or pass additional parameters from the front end depending on who we want 
to control this.

Currently, the full text query does nothing because we don't have a full text index. It's a quirk that this is not considered an error by atlas it just returns zero matching results.

We need to create a full text index on company. We can add this to `MongoDbPreFlightService`, copy the entry for 
_inspections_ to the _company_ entry you added earlier. Unlike creating a database index, the createSearchIndex 
command will not block but the index will take some time to be ready. We are able to poll and see if it's ready but 
in general index creation would be separate from appserver execution, we only have the create-automatically flag 
turned on for development.

```java
private static final String SCHEMA_AND_INDEXES = """
  {
      "collections" : [
        { "name" : "vehicleinspection" ,
          "indexes": [ { "vehicle.model" : 1 }],
          "searchIndexes" : [ { "name": "default", "definition" : { "mappings" : { "dynamic" : true, fields: {}} }}]
        },
        { "name" : "vehicleinspection_history" ,
          "indexes" : [ { "recordId" : 1, "timestamp" : 1 }]
        },
         { "name" : "company" ,
          "indexes": [ { "regAddress.postTown" : 1 }],
          "searchIndexes" : [ { "name": "default", "definition" : { "mappings" : { "dynamic" : true, fields: {}} }}]
   
        }
      ]
  }
  """;


```

Once you add this restart the service. You have now created a default test index on every field - this is not really 
what you want to do in production as maintaining an index on every value in every field is expensive as are queries 
over every field, you are more likely to choose a subset of fields to index. Test in the GUI, we are not 
highlighting your search term in this UI but this _is_ something Atlas search can return data for.

__You may need to wait a short time for the index to build, search indexes build asynchronously__

#### Add an endpoint to text search in a specific field.



Atlas search uses the Aggregation framework , this is used for Search, Joins and other extensions to basic querying, 
we will see it more in  detail later. For now, we want to build a simple text query on peoples full names. with 
an endpoint like `/api/companies/ownerName?name="john"`

In  CompanyRepository is an example of using the `@Aggregation` tag _findAverageMileageByModel_  we need to add 
something but using the $search stage - add the following in `CompanyRepository`:

```java
 @Aggregation( pipeline = {"""
  { 
    "$search": {
      "index": "default",
      "text": {
        "query": ?0,
        "path": "people.name"
      }
    }
  }
"""})
  List<Company> searchOwnerByName(String name);

```
Then add it to `CompanyQueryService`

```java
public List<Company> searchOwnerByName(String name) {
 return repository.searchOwnerByName(name);
}

```
And hook it up to an HTTP endpoint in the `CompanyController`
```java
// Simple Repository Search Example
@GetMapping("/companies/ownerName")
public ResponseEntity<List<Company>> getOwnersByName(
       @RequestParam(name = "name", required = true)  String name) {
 return ResponseEntity.ok(queryService.searchOwnerByName(name));
}

```


Now you can test it using cURL. Once again jq helps us just pull out the fields we want to see from the array of people.

```shell
 curl -s  "http://localhost:8080/api/companies/ownerName?name=cooke" | jq -c ".[] | [.people[].name]"
```

#### Add a fuzzy query option

To make a search 'Fuzzy' we can change the Lucene search request we send, we could change this in UI Javascript
easily but this is a Java course so let's create an endpoint that does a fuzzy search on name. The simplest place to
add this is in the Repository.

We would like that to be optional, the @Aggreagtion annotation is easy  but not very flexible with options, instead 
we need to add explicit code to construct our annotation. We could add searchOwnerByNameFuzzy as an annotation with 
a different definition and call one or the other form our service but let's dive into adding it as code instead, we 
would need this for any more complicated example anyway.

To do this we can add an additional interface and class to the same file.

Add this to the end of `CompanyRepository.java` after the end of the CompanyRepository interface. Also remove the 
version we added above using the @Aggregation annotation. Import as required, _Document_ here is `org.bson.Document`

```java
interface CustomCompanyRepository {
  List<Company>  searchOwnerByName(String name, Boolean fuzzy);
}

class CustomCompanyRepositoryImpl implements CustomCompanyRepository {

  private final MongoTemplate mongoTemplate;
  public CustomCompanyRepositoryImpl(MongoTemplate mongoTemplate) {
    this.mongoTemplate = mongoTemplate;
  }

  @Override
  public List<Company> searchOwnerByName(String name, Boolean fuzzy) {
    List<AggregationOperation> operations = new ArrayList<>();

    // Conditional search stage
    Document searchDetails = new Document("query", name)
            .append("path", "people.name");
    if(fuzzy) {
      searchDetails.put("fuzzy", new Document());
    }
    Document search =
            new Document("$search",  new Document("text", searchDetails));
    operations.add( context -> search);


    // Finalize the aggregation
    org.springframework.data.mongodb.core.aggregation.Aggregation aggregation =
            org.springframework.data.mongodb.core.aggregation.Aggregation.newAggregation(operations);
    return mongoTemplate.aggregate(aggregation, getCollectionName(Company.class), Company.class).getMappedResults();
  }
}

```

Then, in the same file, add `CustomCompanyRepository` to the list of classes `CompanyRepository` extends

```java
@Repository
public interface CompanyRepository
    extends MongoRepository<Company, String>,
        OptimizedMongoLoadRepository<Company>,
        OptimizedMongoQueryRepository<Company>,
        OptimizedMongoDownstreamRepository<Company>,
        MongoHistoryRepository<Company, String>,
        CustomCompanyRepository  {

```
You will also need to update the Service and Controller to pass the 'fuzzy' boolean option

__CompanyQueryService__

```java
 public List<Company> searchOwnerByName(String name, Boolean fuzzy) {
    return repository.searchOwnerByName(name,fuzzy);
  }


```

__CompanyController__
```java

@GetMapping("/companies/ownerName")
public ResponseEntity<List<Company>> getOwnersByName(
  @RequestParam(name = "name", required = true)  String name,
  @RequestParam(name = "fuzzy", required = false, defaultValue = "false")  Boolean fuzzy) {
  return ResponseEntity.ok(queryService.searchOwnerByName(name,fuzzy));
}
```

Now restart and compare the fuzzy and exact matches. In this case fuzzy is using a simple Levenshtein distance adding or removing characters to find matches. Atlas search contains more sophisticated 'fuzzy' options like Soundex and NGram based matching.

Exact

```shell
 curl -s  "http://localhost:8080/api/companies/ownerName?name=cooke" | jq  ".[] | [.people[].name]"

```
Fuzzy
```shell
 curl -s  "http://localhost:8080/api/companies/ownerName?name=cooke&fuzzy=true" | jq  ".[] | [.people[].name]"

```

<div style="border: 2px solid black; background-color: springgreen; padding: 10px;">
  At this point your instructor will talk to you about updates, transactions and locking.
do so.
</div>


## Sprint Four - Locking, Updates and Transactions

```txt
 From: ProductManager@SomeCo.com 
 To: DataTeam@SomeCo.com
 Subject:  Annotations and Notes

OK the marketing folks asked if they can "tag and annotate" the data, they don't 
want to modify any of it but they would like to add keywords and notes to things.
 
A simple array of strings with dates apparently , oh and remove those nodes too 
so I guess they all need some form of identifier. Sometimes they have multiple people 
working on the same record so be careful not to overwrite others comments. And of course
the comments cannot get lost if the upstream data changes and we reload it.

I'm betting they will need to search these too alongside the company data, if not now 
then at some future point.

```

### Sprint Four - Backlog

* Add an endpoint to push a note to a Company
* Add an endpoint to remove a note from a Company
* Ensure we aren't removing notes when we refresh the data

#### Adding an annotation


We want to add something like `/api/companies/notes/<CompanyId>` which we can POST to that creates a new note 
and `/api/companies/notes/<CompanyId>/<NoteId>`  which we can use DELETE  within the first instance. We should be able 
to do both using annotations in the repository. Let's do that first using the `@Update` annotation with a `@Query`. 
We are using an ObjectID here as the commentId - this is a compact 12 byte GUID with good indexing properties often 
used as a GUID in MongoDB.

in CompanyRepository

```java
@Query("{ 'companyNumber' : ?0 }")
@Update("{ '$push' : { 'marketingComments' : { 'commentId': ?2, 'comment': ?1 , 'commentDate': ?3}} }")
void addComment(String companyNumber, String comment, ObjectId commentId, Date commentDate);




@Query("{ 'companyNumber' : ?0 }")
@Update("{ '$pull' : { 'marketingComments' : { 'commentId': ?1} }}")
void deleteComment(String companyNumber,  ObjectId commentNumber);

```

To add a note we want to use `$push` to put an object into an array, we can construct our note object in our service,
so  let's wire that service up first. But which service? This is a new area of functionality so we should create a 
new one `services/CompanyAnnotationService`. 

```java
package com.johnlpage.memex.service;
import com.johnlpage.memex.repository.CompanyRepository;
import org.bson.types.ObjectId;
import org.springframework.stereotype.Service;
import java.util.Date;

@Service
public class CompanyAnnotationService
{
   private final CompanyRepository companyRepository;


   public CompanyAnnotationService(CompanyRepository companyRepository) {
       this.companyRepository = companyRepository;
   }


   public String addAnnotation( String companyId, String note) {
       ObjectId noteId = new ObjectId();
       Date now = new Date();
       companyRepository.addComment( companyId,  note , noteId, now);
       return noteId.toString();
   }


   public void deleteAnnotation( String companyId, String commentIdString) {
       ObjectId commentId = new ObjectId(commentIdString);
       companyRepository.deleteComment(companyId, commentId);
   }
}
```

And we can add endpoints to access this in `CompanyController`

```shell
private final CompanyAnnotationService annotationService;

@PostMapping("/companies/comments/{companyNumber}")
public ResponseEntity<String> addComment(@RequestBody String comment,  @PathVariable String companyNumber) {
 String commentId = annotationService.addAnnotation(companyNumber,comment);
 return ResponseEntity.ok(commentId);
}

@DeleteMapping("/companies/comments/{companyNumber}/{commentId}")
public ResponseEntity deleteComment(@PathVariable String companyNumber, @PathVariable String commentId) {
   annotationService.deleteAnnotation(companyNumber,commentId);
 return ResponseEntity.ok().build();
}

```

Now let's restart and test adding and deleting a note.

#### Adding a note

```shell
 curl -X POST   "http://localhost:8080/api/companies/comments/5497979" -H "Content-Type: text/plain"  -d 
 "GINGERBREAD CAMPAIGN EMAIL SENT"
```

That returns us a hex value, an ID for the note , we can use that to delete it again. You might want to wrap the 
responses in JSON or even have it confirm it did delete something in future.

```shell
 curl -X DELETE   "http://localhost:8080/api/companies/comments/5497979/67ee970855fef239e4b0be90" 
```

We want to take a look, though, let's add a note a company we see in the web UI, In the web UI quuery for company 
number "SL005343" - they are "LMBS". Now add a note to them

```shell
 curl -X POST   "http://localhost:8080/api/companies/comments/SL005343" -H "Content-Type: text/plain"  -d "GINGERBREAD 
 CAMPAIGN EMAIL SENT"
```

Now look at the data again in the Web UI- ___why is the comment missing??___

The answer is because we put it in a field called _marketingComments_ which our current model doesn't read, we have a 
set of defined fields, one of which handles inbound unknown fields and is called payload but reading from the 
database it is ignoring _marketingComments_. We need to add the _marketingComments_ field to our model for Company 
if we want to see it (You can see it in MongoDB tools like Compass that show everything).

Update the `Company` model class like so:

```java
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Document(collection = "company")
public class Company {
 @Id String companyNumber;
 Date incorporationDate;
 Address regAddress;


 List<Map<String,Object>> people;
 List<Map<String,Object>> marketingComments;
```

Whilst we could create a comments class for them, we don't need to just now (we can also have the comment itself be 
more than just a string if it was sent as JSON we could parse that and store it as an object). Here we add 
comments as a top level array of Maps.

When we look in the GUI or see this as JSON it's returned like this. Look at the document in the web UI now ( after 
restarting the appserver of course).

```json
 "marketingComments": [
    {
      "commentId": "67d3f93ae6030b4015b4112b",
      "comment": "GINGERBREAD CAMPAIN EMAIL SENT",
      "commentDate": "2025-03-14T09:39:06.260+00:00"
    }
  ]
```

In the Spring _ObjectMapper_ config we have code that explicitly tells it to serialize the _ObjectId_ to a hex string 
as that's the most useful form. Technically as an ObjectId starts with a timestamp we could use that and not need 
_commentDate_ but this way is easier to think about and query.

___Note how all this can be done with zero fuss, no pushing out schema changes, no data migration. Welcome to MongoDB___

#### Updating versus Replacing data

We also need to talk about what happens when we update data. Until now, we have done a "Replace" this is the 
simplest option to modify an existing document, but it doesn't work for us anymore.

When our next batch of documents comes in from the upstream system if we use'replace' as our write strategy (The 
only option Spring Data offers natively) then replace sends the whole document to MongoDB, MongoDB determines if 
_anything_ has changed and if so overwrites the  whole document. This would mean that anything with 
marketingComments would 
1. Be seen as changed even if the incoming document had not and 
2. Would then be overwritten removing the marketing comments.

The naive Spring view of this is that you must read every document, merge the incoming data with the old data and write 
it back - this is incredibly inefficient not least because Spring doesn't natively support batches as we saw. So how 
do we resolve this?

In general MongoDB doesn't recommend replace() it's too brute force. But we have some great alternatives.

Imagine your JSON looks like this, that ultimately gets converted to a Document Object (HashMap)

```js
var document = {
  "companyNumber": "5497979",
  "incorporationDate": "2005-07-04T00:00:00.000+00:00",
  "regAddress": {
    "addressLine1": "FLAT 9, WYATT PARK MANSIONS",
    "addressLine2": "STREATHAM HILL",
    "postTown": "LONDON",
    "postCode": "SW2 4RN",
  }
}

```

The API call used to send that for a replace, at it's simplest looks like this 

```js
var query = { companyNumber : document.getString("companyNumber")}

collection.replaceOne( query, document ); // Find by number and overwrite

```


But we have seen that updates can set specific fields and those fields are defined as an object so instead or 
replace we do this to tell it to set all the fields in the document.

```json
var query = { companyNumber : document.getString("companyNumber")}

var updates =  { $set : document }
collection.updateOne( query, updates ); // Find by number and overwrite

```
This tells it to set each field individually, and importantly leaves all the other fields alone. It also has the 
advantage that only fields which are changing are recorded in the transaction log rater than the whole document, 
which means less network bandwidth to replicate and also lower differential backup costs.

We can actually go a step further, in this example is any field in regAddress changes, then regAddress is overridden 
, and thinking that through if any field in 'payload' changed then payload is overridden, but we can unwind object 
to tell it to set individual fields - so we could programmatically rewrite that to look like this.

```js
var flattened = unwindDocument(doc)

// flattened now looks like
{  "companyNumber": "5497979",
   "incorporationDate": "2005-07-04T00:00:00.000+00:00",
   "regAddress.addressLine1": "FLAT 9, WYATT PARK MANSIONS",
   "regAddress.addressLineaddressLine2": "STREATHAM HILL",
   "regAddress.addressLine.postTown": "LONDON",
   "regAddress.addressLine.postCode": "SW2 4RN" }

var query = { companyNumber : document.getString("companyNumber")}

var updates =  { $set : flattened }
collection.updateOne( query, updates ); // Find by number and overwrite

```
This is all done for us inside the MEMEx framework inside the optimizedMongoDBLoader - all we need to do is make 
sure we use updateStragegy UPDATE not REPLACE( THe default ), you can try this now.

__Find a Document in the UI__

Take a note of the companyNUmber to use below.

#### Add a Comment
```shell
curl -X POST   "http://localhost:8080/api/companies/comments/SL005343" -H "Content-Type: text/plain" \
  -d "This will vanish"
```

#### View Comment in web UI

#### Reload data set with the default (REPLACE)

```shell
curl -X POST "http://localhost:8080/api/companies" -H "Content-Type: application/json" -T companies250k.json
```

#### Vew in WebUI again
Note the comment has gone. because although the upstream record is the same, it's not the same as the one in the 
database anymore so we overwrite it.

#### Add the comment again
```shell
curl -X POST   "http://localhost:8080/api/companies/comments/SL005343" -H "Content-Type: text/plain"  -d "This will 
NOT vanish"
```
#### Reload using Update

```shell
curl -X POST "http://localhost:8080/api/companies?updateStrategy=UPDATE" -H "Content-Type: application/json" -T companies250k.json
```

In general, using this update strategy is no slower than using replace and so should almost always be preferred. By 
design, as it does not remove other fields if the upstream system removes a field from the feed that will not be 
removed for the database, this is the only significant caveat.

<div style="border: 2px solid black; background-color: springgreen; padding: 10px;">
  At this point your instructor will talk to you about Aggregation pipelines and expressive pipeline updates. Do not 
continue 
beyond this point until asked to do so.
</div>

## Sprint Five - Reporting and Aggregations

```txt
from: Product Manager
to: Data Team
Subject: Reporting on the Company Data

A couple of requirements here.
 
Marketing wants a report on what records have been worked on since a given date. Things with changes to comments 
basically.

They would also like a report on what data has changed so new records, records where data has changed 
and especially records that have changed that are also tagged with specific tags. Ideally with the changes.
This should dump those records so they can be fed to another systems.

```

### About Update With History

We currently update records by setting each individual field to the value from the supplied JSON and if anything 
changes the record is updated and if not it isn't but how can we tell if a record did change or not?

One option is to look at the transaction log, or OpLog - there is an API to do this called a change stream but that 
means we need to have a listener to that, and it would need to be highly available, technically we could open a 
stream on the oplog, write our changes then listen for them being committed and use that data to record a history or 
update them again to add a list updated date. We would not see them in the oplog until we have already committed our 
write transaction though.


The MEME framework uses a different approach, this is our final update strategy called UpdateWithHistory. This uses a 
pipeline  update which allows you to break the update into a number of stages and perform each including 
programmatic expressions so we perform the following.

1. Add to the document an empty object called _delta, add to this a last update date and a unique identifier for this 
batch update
2. For each field in our unwound object, if the current value of the field is different to the new value then write 
   the current value into the _delta object
3. Set each field to the new value
4. If no values were added to delta (nothing had changed) delete delta otherwise update with this new form.

Now each object has a sub object showing the prior values of fields changed in the last update, the time of that 
update and also a unique identifier.

When we use the UpdateWithHistory mode the update is performed inside a transaction. A batch of documents is 
updated as above then a postUpdateTrigger is called if defined. The client-side trigger code gets passed the new 
documents, the update identifier, and details of what changed. It can fetch those _delta objects and write 
them into an audit trail / history.

This also means we have a _delta.lastUpdate field in each document but we don't see that thanks to the model. This 
only contains the last set of changes and whist we could make another call to remove in our transaction it's not 
worth it usually.

To test this we need to have data that change. We can modify a single document and load it or we can make use of 
preWrite trigger to programmatically alter multiple documents. PreWrite triggers are called, if defined before each 
incoming document is written to the database, you can use them for enrichment or to generate test data by modifying 
sample data.

### Sprint 5 Backlog

* Provide an endpoint to get records modified by a new comment
* Ensure modified records from upstream have a last updated date
* Provide an endpoint to get records with changes from upstream.
* Modify the endpoint to get records modified by comment or date that optionally have a specific comment sorted by 
  date

### Step by step

#### Finding new Comments

To find records with new comments we really just want to add a new endpoint, although we should make this a streaming 
one as there might be quite a few. Until now, we have mostly returned single records or  pages of documents or, in a 
few cases, a large set (10,000) but we haven't accounted for very large sets. With very large returned sets we want to 
stream results from the database not put them into a List in the appserver where we will likely run out of heap and 
crash.

Our `DownstreamService` is intended to do this, returning a stream of objects both in the Spring typical way and in 
a more efficient MongoDB native way that avoids additional object creation and garbage collection.

Currently, there are two methods, both of which return the entire data set _jsonExtractStream_ and 
_nativeJsonExtractStream_ - we want to add the option to get modified data only to this.

First  we need to create the repository function - this should be simple  to add to `CompanyRepository`

```java
@Query("{ 'marketingComments.commentDate' : { $gte : ?0 }}")
Stream<Company> getNewComments(Date since);
```

Then `CompanyDownstreamService` copy `jsonExtractStream` and rename to `jsonExtractNewCommentStream`

```java
public Stream<Company> jsonExtractNewCommentStream(Date since) {
 return repository.getNewComments(since);
 }
```

Finally add it in the Controller - we can duplicate the `jsonStream` which includes the code that streams the results 
back

```java
@GetMapping(value = "/companies/newcomments", produces = MediaType.APPLICATION_JSON_VALUE)
public StreamingResponseBody streamUpdatedSince(@RequestParam(name = "since", required = true)
                                                @DateTimeFormat(pattern="yyyyMMdd")  Date since) {

    return outputStream ->
            writeDocumentsToOutputStream(outputStream, downstreamService.jsonExtractNewCommentStream(since));
  }
```

#### Test

We can now restart the appserver and add a comment, then query and see if we get back the things we added comments to.

```shell
 curl -X POST   "http://localhost:8080/api/companies/comments/5497979" -H "Content-Type: text/plain"  -d "NEW COMMENT TODAY"
 
 curl  "http://localhost:8080/api/companies/newcomments?since=20250314"
```

This once again needs an index to support it so we should ideally add one in MongoDbPreflightCheckService.

### Finding modified records 

Now let's see if we can get a last modified date. As stated before just adding in a last update date is problematic 
as just setting the date itself is a modification, but we can load in out data using UpdateWithHistory if we simply 
run an update wit hhistory we should get no changes. Which means no last modified dates either. Let's look in detail 
how this works.

If we look in `CompanyController` we see this creates a `CompanyPreWriteTriggerService`  which we pass to 
`loadFromJsonStream` if futz=true. I'm sure there are many reasons we can think of to modify data between loading it 
from upstream JSON and writing to the DB, that's what this is for but in this case we will use it to modify a small 
portion of the sample data to pretend each load has some upstream changes.

We are using mutable models in our code so we can change the modifyMutableDataPreWrite function. Let's keep it very 
simple and  set a field to a random value in some documents. In the VehicleInspection pre-write triggers we make 
more business related changes when modifying data for testing. We could also assign new Business Numbers (to 
generate fake new documents) or set delete to true to remove records.

Modify the code in `CompanyPreWriteTriggerService` as follows, it's adding a new value _creditScore_ to a small 
percentage of the data before loading it:

```java
/** This Code is for mutable models */
@Override
public void modifyMutableDataPreWrite(Company document) {
 if (rng.nextDouble() < 0.001) {
   document.getPayload().put("creditScore",rng.nextInt(500,900));
 }
}
```


So now we have our futzer let's load with History and capture the changes it makes.

Before we do so,  please take a quick look at `services\generic\HistoryTriggerService` which we are using for this. Post 
write trigger is called after each batch of writes happen before the transaction is committed.  Because this works in 
transactions and also in parallel, we need to avoid the situation where two transactions both try to create a new 
collection (the company_history) . So we need to add the history collection (company_history)  to the preflight 
service so it's there before transactions write to it. We also need an index to get back history data for a given 
record quickly.

```java
private static final String SCHEMA_AND_INDEXES =
        """
{
   "collections" : [
     { "name" : "vehicleinspection" ,
       "indexes": [ { "vehicle.model" : 1 }],
       "searchIndexes" : [ { "name": "default", "definition" : { "mappings" : { "dynamic" : true, fields: {}} }}]
     },
     { "name" : "vehicleinspection_history" ,
       "indexes" : [ { "recordId" : 1, "timestamp" : 1 }]
     },
      { "name" : "company" ,
       "indexes": [ { "regAddress.postTown" : 1 }],
       "searchIndexes" : [ { "name": "default", "definition" : { "mappings" : { "dynamic" : true, fields: {}} }}]


     },
      { "name" : "company_history" ,
       "indexes" : [ { "recordId" : 1, "timestamp" : 1 }]
     },
   ]
}
""";

```

Restart  and load the data, you should see about 0.1% of records are updated.

```shell
curl -s -X POST "http://localhost:8080/api/companies?updateStrategy=UPDATEWITHHISTORY&futz=true" \
-H "Content-Type: application/json" -T companies250k.json
```

Now we have two collections, `company` and `company_history`. The company collection contains the current version and 
also, details of what changed in the last update although this is more for internal use. `company_history` contains a timestamped view of all previous updates.

Coming back to our requirements"

* Provide an endpoint to get records with changes from upstream.
* Modify the  endpoint to get records modified by comment or date that optionally have a specific comment sorted by date


Getting all updated upstream records and ignoring comments makes sense as a service for  providing this data to someone 
else. The intent is simply provide a copy of the data downstream but unlike the data we get where we need to 
work out what has changed, our downstream consumers can have just the deltas without us  sending all of it each time.
Again, extraction from cloud costs more than ingestion.

Let's add that feature first in `CompanyRepository`

```java
@Query("{ '__previousValues.__lastUpdateDate' : { $gte : ?0 }}")
Stream<Company> getUpdatedCompanies(Date since);
```
Then in `CompanyDownstreamService`

```java
public Stream<Company> jsonExtractUpdatedCompanies(Date since) {
 return repository.getUpdatedCompanies(since);
}

```

Finally in `CompanyController`

```java
 @GetMapping(value = "/companies/updated", produces = MediaType.APPLICATION_JSON_VALUE)
  public StreamingResponseBody streamUpdatedCompanies(@RequestParam(name = "since", required = true)
                                                      @DateTimeFormat(pattern="yyyyMMdd")  Date since) {
    return outputStream -> writeDocumentsToOutputStream(outputStream, downstreamService.jsonExtractUpdatedCompanies(since));
  }
```

Test as below. Note we are only parsing dates not datetimes but you coudl change the baove to include times, MongoDB 
always stores Dates with Times.

```shell
curl "http://localhost:8080/api/companies/updated?since=20250314"
```

One further wrinkle is this is not finding documents that have been deleted (assuming we have chosen to delete 
documents only from our Company collection and not from the history too). To get that feature we would need to 
change to  using an aggregation to look in both company and company history. Let's delete one of our documents then 
get back what's updates and deleted.

__At this point to make things as little easier to see we are  going to empty our database and start again, using 
compass or the mongo shell drop the memex database and all collections__

Restart the service and load in just the first 5 companies in the sample data

```shell
head -5 companies250k.json > small.json

 curl -s -X POST "http://localhost:8080/api/companies?updateStrategy=UPDATEWITHHISTORY" -H "Content-Type: application/json" -T small.json


{"updates":0,"deletes":0,"inserts":5,"success":true,"message":""}
```
Now edit small.json and add `"deleted:true"` to one of the json documents before reloading it

```shell
 curl -s -X POST "http://localhost:8080/api/companies?updateStrategy=UPDATEWITHHISTORY" -H "Content-Type: application/json" -T small.json
 
 {"updates":0,"deletes":1,"inserts":0,"success":true,"message":""}
```

Now we can query and we should only see the 4 remaining records as we are not yet considering deletions.

```shell
curl "http://localhost:8080/api/companies/updated?since=20250314" | jq .companyNumber

```

### Include deletions in change extract

#### Update Repository

First we will simply move from a Query to an Aggregation, this aggregation will have s single stage which is $match 
and is exactly like our Query. Change in `CompanyRepository` , restart the service and verify you get the same result.

```java
@Aggregation( pipeline = {
"""
{ '$match' : { '__previousValues.__lastUpdateDate' : { $gte : ?0 }}}
"""
})
Stream<Company> getUpdatedCompanies(Date since);
```

As this is now an aggregation we can do a lot more - we will use $unionWith to also return results from a second 
collection. Modify this in `CompanyRepository` to now read as follows. Spring does not make these pretty but they 
are readable. 

```java
@Aggregation( pipeline = {
"""
{ '$match' : { '__previousValues.__lastUpdateDate' : { $gte : ?0 }}}
""",
"""
{ '$unionWith' : { 'coll' : 'company_history',
                  'pipeline' : [
                      {'$match' : { 'timestamp' : { $gte : ?0 }, type:'delete'}},
                      { '$project' : { '_id' : '$recordId', 'payload.delete' : {$literal: true} }}
                   ]
      }
}
"""
})
Stream<Company> getUpdatedCompanies(Date since);

```

Test this to make sure you see all 5 again

```java
curl "http://localhost:8080/api/companies/updated?since=20250314" "
```

The final request was to return documents that have changed either because of a new comment or a change  from upstream 
and where optionally there is a specific comment. We can do this using $or, we will add a new entry in the repository.

```java
 @Query(
"""
{ '$or' : 
 [
   { 'marketingComments.commentDate' : { $gte : ?0 }},
   {'__previousValues.__lastUpdateDate' : { $gte : ?0 }}
 ]
}
""")
 Stream<Company> getAnyUpdate(Date since);

```
And in `CompanyDownstreamService`

```java
public Stream<Company> jsonExtractAllUpdates(Date since,String comment) {
 return repository.getAnyUpdate(since);
}
```

And in `CompanyController`.

```java
@GetMapping(value = "/companies/allupdates", produces = MediaType.APPLICATION_JSON_VALUE)
public StreamingResponseBody streamNewComments(@RequestParam(name = "since", required = true)
                                              @DateTimeFormat(pattern="yyyyMMdd")  Date since,
                                              @RequestParam(name = "comment", required = false) String comment) {
 return outputStream -> writeDocumentsToOutputStream(outputStream, 
                                                      downstreamService.jsonExtractAllUpdates(since,comment));
}

```

Finally, we want to filter this to only things that have a specific comment, what we can do it put a comment on a 
couple of them then query for changed since 'Today'.
```shell


curl -X POST   "http://localhost:8080/api/companies/comments/13522064" -H "Content-Type: text/plain"  -d "FLAGGED"

curl -X POST   "http://localhost:8080/api/companies/comments/11743365" -H "Content-Type: text/plain"  -d "FLAGGED"
```


Now we need a new entry in our Repository. There are two ways we could write this `( comment AND ( updateDate or 
commentDate)` or `( ( comment AND updateDate) OR (comment AND commentDATE))`. The second one allows us to efficiently 
use two different indexes as you can use a new index for each top level `OR` clause so we will write it like that.
Note that we are not looking for the _commentDate_ and the comment text to be in the same comment in this case so we 
are not using the `$elemMatch` query operator to scope it to a single array entry.

In `CompanyRepository`

```java
@Query(
     """
{ '$or' :
 [
   { 'marketingComments.commentDate' : { $gte : ?0 }, 'marketingComments.comment' :  ?1 },
   {'__previousValues.__lastUpdateDate' : { $gte : ?0 }, 'marketingComments.comment' :  ?1 }
 ]
}
""")
 Stream<Company> getAnyUpdate(Date since, String comment);

```


We need to add this in our `CompanyDownstreamService` service too.

```java
public Stream<Company> jsonExtractAllUpdates(Date since,String comment) {
 if(comment == null || comment.isEmpty() || comment.isBlank())  {
   return repository.getAnyUpdate(since);
 } else {
   return  repository.getAnyUpdate(since,comment);
 }
}
```

Test this

```
curl "http://localhost:8080/api/companies/allupdates?since=20250314" | jq .marketingComments

curl "http://localhost:8080/api/companies/allupdates?since=20250314&comment=FLAGGED" | jq .marketingComments

```


<div style="border: 2px solid black; background-color: springgreen; padding: 10px;">
  At this point your instructor will talk to you more Aggregation pipelines including JOINS with $lookup and how to 
use them. Please do not proceed until asked to do so.
</div>

## Sprint 6 - Querying into the past with $lookup on history.

```txt
From: Product Manager
to: Data Team
Subject: History Search?

You are all doing a great job but I think they are really getting silly now. Three requests although the first two 
may be the same thing.

Can we please see how a specific record looked at a given point in time
Can we see what a set of records looked like at a PiT 
Can we query historic records, we want to be able to query for something as  it was a value then see what records it was a value in. We might want to combine that with the above too. So when record existed that said X did it also say Y ?


```


### Sprint 6 backlog

* Load some test data
* Fetch Test company
* Fetch Tet company with History
* Index historic data
* Query Current and Historic then fetch

To make this easy we want to load in some company data. Your instructor will supply you with a set of 4 json files.
Paste these update lines in one at a time so they don't all happen in the same millisecond.


```shell

curl  -X POST "http://localhost:8080/api/companies?updateStrategy=UPDATEWITHHISTORY" -H "Content-Type: application/json" -T v0.json
```


Now get the date and time before any updates , take a note of it.
```
date +"%Y%m%d%H%M%S"
```


```shell
curl  -X POST "http://localhost:8080/api/companies?updateStrategy=UPDATEWITHHISTORY" -H "Content-Type: application/json" -T v1.json
```
```
curl  -X POST "http://localhost:8080/api/companies?updateStrategy=UPDATEWITHHISTORY" -H "Content-Type: application/json" -T v2.json
```

```
curl  -X POST "http://localhost:8080/api/companies?updateStrategy=UPDATEWITHHISTORY" -H "Content-Type: application/json" -T v3.json
```

Take a look in Compass at that - The company number is "8209948", We have 4 entries, insert then a name change and  2 changes to status


Now we want to use an endpoint to get this document at time X. We have one to fetch a document by ID at a given
point in time. Take time to look at the pipeline that makes this work `repository/optimized/MongoHistoryRepository`
and discuss with your instructor , perhaps taking it from the debug log.



```shell
#Latest versions
curl "http://localhost:8080/api/companies/id/8209948" | jq .
#Historic (original) version
curl "http://localhost:8080/api/companies/asOf?id=8209948&asOfDate=XXXXXXXX" |jq .
```

Youc an compare the JSON files to the output to check but the original address is at number 9 and the company at some point moved to number 11 , you can see this as a difference in these outputs.


Final Challenges:

Discuss these with your instructor, or implement them if you have time. They are all possible but the sample code is
not part of the MEMEx framework yet.

* Adapt the code to show what all companies a given person is involved with looked like in a prior version.

* How can we adapt the code to query the history for a person and then fetch the last version of the record where that
  person was involved?

* How can we query for the last version of a record where multiple things were true, were some or all may not now be true.

